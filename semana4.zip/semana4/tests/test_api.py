from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_create_book():
    response = client.post("/books/", json={"title": "Libro A", "author": "Autor A"})
    assert response.status_code == 200
    assert response.json()["title"] == "Libro A"

def test_create_user():
    response = client.post("/users/", json={"name": "Juan", "email": "juan@test.com"})
    assert response.status_code == 200
    assert response.json()["email"] == "juan@test.com"

def test_create_loan_and_return():
    book = client.post("/books/", json={"title": "Libro B", "author": "Autor B"}).json()
    user = client.post("/users/", json={"name": "Ana", "email": "ana@test.com"}).json()

    loan = client.post("/loans/", json={"user_id": user["id"], "book_id": book["id"]})
    assert loan.status_code == 200

    loan_id = loan.json()["id"]
    return_loan = client.put(f"/loans/{loan_id}/return")
    assert return_loan.status_code == 200
    assert return_loan.json()["return_date"] is not None

