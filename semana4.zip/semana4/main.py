from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
from database import engine, Base, get_db
import crud, models, schemas

# Crear tablas
Base.metadata.create_all(bind=engine)

app = FastAPI(title="Biblioteca API")

# ----- BOOK -----
@app.post("/books/", response_model=schemas.BookOut)
def create_book(book: schemas.BookCreate, db: Session = Depends(get_db)):
    return crud.create_book(db, book)

@app.get("/books/", response_model=list[schemas.BookOut])
def list_books(db: Session = Depends(get_db)):
    return crud.get_books(db)

# ----- USER -----
@app.post("/users/", response_model=schemas.UserOut)
def create_user(user: schemas.UserCreate, db: Session = Depends(get_db)):
    return crud.create_user(db, user)

@app.get("/users/", response_model=list[schemas.UserOut])
def list_users(db: Session = Depends(get_db)):
    return crud.get_users(db)

# ----- LOAN -----
@app.post("/loans/", response_model=schemas.LoanOut)
def create_loan(loan: schemas.LoanCreate, db: Session = Depends(get_db)):
    db_loan = crud.create_loan(db, loan)
    if not db_loan:
        raise HTTPException(status_code=400, detail="No se pudo crear el préstamo")
    return db_loan

@app.put("/loans/{loan_id}/return", response_model=schemas.LoanOut)
def return_loan(loan_id: int, db: Session = Depends(get_db)):
    db_loan = crud.return_book(db, loan_id)
    if not db_loan:
        raise HTTPException(status_code=404, detail="Préstamo no encontrado")
    return db_loan

